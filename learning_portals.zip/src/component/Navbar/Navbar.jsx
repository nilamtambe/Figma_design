import React, { useState } from "react";
import { IoMdMenu } from "react-icons/io";
import { motion } from "framer-motion";
import Logo from "../../assets/eLrnstudio-Logo-v1.png";

const NavbarMenu = [
  {
    id: 1,
    title: "Home",
    path: "/",
  },
  {
    id: 2,
    title: "About Us",
    link: "/about",
  },
  {
    id: 3,
    title: "Key Services Overview",
    link: "/services",
  },
  {
    id: 4,
    title: "Client Success Stories",
    link: "/testimonial",
  },
  {
    id: 5,
    title: "Contact Us",
    link: "/footer",
  },
];
const Navbar = () => {

  const[open, setOpen] = useState(false);


  const handleOpen =() =>{
    setOpen(!open);
  }
  return (
    <nav className="container py-5 px-2 sm:py-0 fixed z-10 mx-5">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center"
      >
        {/* Logo section */}
        <div>
        <a href='/#'>
          <img src={Logo} alt="" className='w-16 sm:w-24 m-2'/>
          </a>
        </div>
        {/* Menu section */}
        <div className="hidden lg:block">
          <ul className="flex items-center gap-3 text-white">
            {NavbarMenu.map((menu) => (
              <li key={menu.id}>
                <a
                  href={menu.path}
                  className="inline-block py-2 px-3 hover:text-secondary relative group"
                >
                  <div className="text-white text-2xl w-2 h-2 bg-secondary absolute mt-4 rounded-full left-1/2 -translate-x-1/2 top-1/2 bottom-0 group-hover:block hidden"></div>
                  {menu.title}
                </a>
              </li>
            ))}
            
          </ul>
        </div>
        {/* Mobile Hamburger menu section */}
        <div className="lg:hidden">
          <button onClick={handleOpen}>
          <IoMdMenu className="text-4xl text-white" />
          </button>
          {
            open && (
              <div>
              <ul className="bg-white space-y-3 p-4 rounded-md shadow-md absolute right-10 top-24 z-50">
                {NavbarMenu.map((menu) => (
                  <li key={menu.id}>
                    <a
                      href={menu.path}
                      className="inline-block text-xl p-4 hover:bg-blue-500 hover:text-white w-full rounded-md"
                    >
                      <div className="text-white text-2xl w-2 h-2 bg-secondary absolute mt-4 rounded-full left-1/2 -translate-x-1/2 top-1/2 bottom-0 group-hover:block hidden"></div>
                      {menu.title}
                    </a>
                  </li>
                ))} 
                
              </ul>
              </div>
            )
          }
          
        </div>
      </motion.div>
    </nav>
  );
};

export default Navbar;












